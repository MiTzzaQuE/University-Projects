class ValidationException(Exception):
    pass

class RepoException(Exception):
    pass