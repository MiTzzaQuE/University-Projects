from domain.entities import Produs
from validation.validators import ValidatoriProdus
from errors.exception import ValidationException, RepoException
from infrastructure.repository import RepositoryProdus
from business.services import ServiceProdus

class Tests:
    
    def __run_domain_tests(self):
        '''
            Functie care testeaza funcitonalitatea clasei domeniu
        '''
        id_produs = 23
        denumire = "denumire"
        pret = 50
        produs = Produs(id_produs,denumire,pret)
        assert (produs.get_id_produs()==id_produs)
        assert (produs.get_denumire()==denumire)
        assert (produs.get_pret()==pret)
        produs0 = Produs(id_produs,None,None)
        assert (produs == produs0)
    
    
    def __run_validation_tests(self):
        '''
            Functie care testeaza functionalitatea clasei de validare
        '''
        produs = Produs(-23,"",-50)
        validator_produs = ValidatoriProdus()
        try:
            validator_produs.valideaza(produs)  
            assert False
        except ValidationException as ve:
            assert (str(ve)=="id invalid!\ndenumire invalida!\npret invalid!\n")
        produs_valid = Produs(23,"denumire",50)
        validator_produs.valideaza(produs_valid)
        assert True
    
    
    def __run_repository_tests(self):
        '''
            Functie care testeaza functionalitatea clasei de repository
        '''
        produs = Produs(23,"denumire",50)
        repo_produs = RepositoryProdus("produse_test.txt")
        repo_produs.remove_all()
        assert len(repo_produs)==0
        repo_produs.store(produs)
        assert len(repo_produs)==1
        key = "2"
        repo_produs.remove(key)
        assert len(repo_produs)==0
        repo_produs.store(produs)
        repo_produs.remove("1")
        assert len(repo_produs)==1
    
    
    def __run_service_tests(self):
        '''
            Functie care testeaza functionalitatea clasei de service
        '''
        repo_produs = RepositoryProdus("produse_test.txt")
        valid_produs = ValidatoriProdus()
        service_produs = ServiceProdus(repo_produs,valid_produs)
        repo_produs.remove_all()
        id_produs = 23
        denumire = "denumire"
        pret = 50
        service_produs.add_produs(id_produs, denumire, pret)
        try:
            service_produs.add_produs(id_produs,denumire,pret)
            assert False
        except RepoException as re:
            assert str(re)=="Produs existent!\n"
        try:
            service_produs.add_produs(-id_produs, "", -pret)
            assert False
        except ValidationException as ve:
            assert str(ve)=="id invalid!\ndenumire invalida!\npret invalid!\n"
        repo_produs.remove_all()
            
    
    
    def run_all_tests(self):
        '''
            Functie care apeleza toate functiile de test
        '''
        self.__run_domain_tests()
        self.__run_validation_tests()
        self.__run_repository_tests()
        self.__run_service_tests()
    