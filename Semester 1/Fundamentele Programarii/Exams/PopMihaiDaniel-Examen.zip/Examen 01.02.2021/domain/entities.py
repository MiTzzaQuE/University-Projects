class Produs:
    '''
        Clasa in care se initializeaza elementele de tip Produs
    '''
    
    def __init__(self,id_produs,denumire,pret):
        '''
            Functie de initializare a unui produs
            id_produs - numar intreg, pozitiv
            denumire - tip string
            pret - numar intreg, pozitiv
        '''
        self.__id_produs = id_produs
        self.__denumire = denumire
        self.__pret = pret
        

    def get_id_produs(self):
        '''
            Functie de tip getter
            returneaza id ul unui produs
        '''
        return int(self.__id_produs)


    def get_denumire(self):
        '''
            Functie de tip getter
            returneaza denumirea unui produs
        '''
        return self.__denumire


    def get_pret(self):
        '''
            Functie de tip getter
            returneaza pretul unui produs
        '''
        return int(self.__pret)
    
    
    def __eq__(self,other):
        '''
            Functie care modifica functionalitatea de comparatie de egalitate
            returneaza valoarea din comparatia id-urilor a doua produse
        '''
        return int(self.__id_produs) == int(other.__id_produs)
    
    
    def __str__(self):
        '''
            Functie pentru transformarea parametrilor produsului in string-uri
            returneaza id,denumire,pret
        '''
        return "ID: "+str(self.__id_produs)+"\ndenumire: "+self.__denumire+"\npret: "+str(self.__pret)+"\n"
    

