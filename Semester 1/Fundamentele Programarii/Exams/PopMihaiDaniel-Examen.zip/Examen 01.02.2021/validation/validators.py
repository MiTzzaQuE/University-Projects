from errors.exception import ValidationException

class ValidatoriProdus:
    '''
        Clasa de validare a unui produs
    '''
    
    def valideaza(self,produs):
        '''
            Functie care valideaza un produs de tip Produs
            id_produs - numar intreg, pozitiv
            denumire - string nevid
            pret - numar intreg pozitiv
        '''
        errors = ""
        if(produs.get_id_produs()<=0):
            errors+="id invalid!\n"
        if(produs.get_denumire()==""):
            errors+="denumire invalida!\n"
        if(produs.get_pret()<=0):
            errors+="pret invalid!\n"
        if len(errors)>0:
            raise ValidationException(errors)


