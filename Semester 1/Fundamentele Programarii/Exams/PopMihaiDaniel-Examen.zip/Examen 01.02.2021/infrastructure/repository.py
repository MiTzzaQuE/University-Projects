from domain.entities import Produs
from errors.exception import RepoException

class RepositoryProdus:
    
    
    def __init__(self,nume_fisier):
        '''
            Functie de initializare a repository ului
            nume fisier - numele fisierului in care sunt salvate produsele
        '''
        self.__nume_fisier = nume_fisier
        
        
    def __loadFromFile(self):
        '''
            Functie care incarca din fisier lista cu produse
            returneaza lista
            ridica exceptie de tip IOError daca nu s-a deschis bine fisierul
        '''
        try:
            f = open(self.__nume_fisier,"r")
        except IOError:
            return 
        
        line = f.readline().strip()
        rez=[]
        while line!="":
            curent = line.split(";")
            produs = Produs(curent[0],curent[1],curent[2])
            rez.append(produs)
            line = f.readline().strip()
        f.close()
        return rez
    
    
    def __storeToFile(self,lista):
        '''
            Functie care salveaza in fisier lista de produse
            ridica exceptie de tip IOError daca nu s-a deschis bine fisierul
        '''
        with open(self.__nume_fisier,"w") as f:
            for produs in lista:
                curent = str(produs.get_id_produs())+";"+produs.get_denumire()+";"+str(produs.get_pret())+"\n"
                f.write(curent)
        f.close()
        
        
    def store(self,produs):
        '''
            Functie care adauga un produs la lista de produse
            ridica RepoException daca exista deja produsul in lista
        '''
        lista = self.__loadFromFile()
        
        if produs in lista:
            raise RepoException("Produs existent!\n")
        lista.append(produs)
        self.__storeToFile(lista)
        
    
    def remove(self,key):
        '''
            Functie care sterge toate produsele din fisier care contin cifra key in id
            key - cifra de tip string
            returneaza numarul produselor sterse
        '''
        lista = self.__loadFromFile()
        i=0
        contor=0
        while(i<len(lista)):
            if key in str(lista[i].get_id_produs()):
                del lista[i]
                contor+=1
            else:
                i+=1
        self.__storeToFile(lista)
        return contor

    
    def undo(self,lista):
        '''
            Functie care reface operatia de stergere
            modifica fisierul in care este salvata lista de produse
        '''
        self.__storeToFile(lista)


    def remove_all(self):
        '''
            Functie care sterge toate elem din lista
        '''
        self.__storeToFile([])
        
    
    def get_all(self):
        '''
            Functie care returneaza toate elem listei
        '''
        return self.__loadFromFile()
    
    
    def __len__(self):
        '''
            Functei care returneaza lungimea listei de produse
        '''
        return len(self.__loadFromFile())
