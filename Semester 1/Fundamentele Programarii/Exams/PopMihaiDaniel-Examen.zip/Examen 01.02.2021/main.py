'''
Created on 01 feb. 2021

@author: mihai
'''

from testing.tests import Tests
#from domain.entities import Produs
from validation.validators import ValidatoriProdus
from infrastructure.repository import RepositoryProdus
from business.services import ServiceProdus
from presentation.console import UI

if __name__ == '__main__':
    '''
        Functia principala care apeleaza toate functiile
    '''
    
    tests = Tests()
    tests.run_all_tests()
    
    repo_produs = RepositoryProdus("produse.txt")
    valid_produs = ValidatoriProdus()
    
    srv_produs = ServiceProdus(repo_produs,valid_produs)
    
    cons = UI(srv_produs)
    cons.run()