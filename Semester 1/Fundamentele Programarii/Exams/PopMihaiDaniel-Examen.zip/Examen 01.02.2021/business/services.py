from domain.entities import Produs

class ServiceProdus:
    
    def __init__(self,repo_produs,valid_produs):
        '''
            Functie de intializare a clasei de service pentru produse
            repo_produs - clasa de RepositoryProdus
            valid_produs - clasa de ValidatoriProdus
        '''
        self.__repo_produs = repo_produs
        self.__valid_produs = valid_produs
        self.__lista_undo = []
        
        
    def add_produs(self,id_produs,denumire,pret):
        '''
            Functie care primeste ca parametrii datele unui produs, creeaza produsul si apeleaza functia de validare si adaugare in lista
            id_produs - numar intreg
            denumire - string
            pret - numar intreg
        '''
        produs = Produs(id_produs,denumire,pret)
        self.__valid_produs.valideaza(produs)
        self.__repo_produs.store(produs)
        
    
    def delete_produs(self,key):
        '''
            Functie care primeste ca parametru o cifra de tip string
            apeleaza functia de stergere a produselor din lista care contin in id cifra data
            returneaza numarul produselor sterse
        '''
        lista = self.get_produs()
        self.__lista_undo.append(lista)
        return self.__repo_produs.remove(key)
    
    
    def filtrare(self,key1,key2):
        '''
            Functie care filtreaza lista in functie de 2 key-uri date
            key1 - dupa denumire
            key2 - dupa pret
        '''
        lista = self.__repo_produs.get_all()
        rez=[]
        if key1=="" and key2==-1:
            return lista
        elif key2==-1:
            for produs in lista:
                if key1 in produs.get_denumire():
                    rez.append(produs)
        elif key1=="":
            for produs in lista:
                if produs.get_pret()<key2:
                    rez.append(produs)
        else:
            for produs in lista:
                if key1 in produs.get_denumire() and produs.get_pret()<key2:
                    rez.append(produs)
        return rez
    
    
    def undo(self):
        '''
            Functia care reface operatia de stergere
        '''
        lista = self.__lista_undo.pop()
        self.__repo_produs.undo(lista)
    
    
    def get_no_produs(self):
        '''
            Functie care returneaza lungimea listei de produse
        '''
        return len(self.__repo_produs)
    
    
    def get_produs(self):
        '''
            Functie care returneaza toate elementele listei de produse
        '''
        return self.__repo_produs.get_all()
