from errors.exception import ValidationException,RepoException


class UI:
    
    def __ui_print_meniu(self):
        '''
            Functie care afiseaza meniul aplicatiei
        '''
        print("Gestiunea produselor unui magazin: \n")
        print("0.meniu = Meniul principal")
        print("1.add = Adaugarea unui produs")
        print("2.del = Stergerea produselor care contin cifra data in id")
        print("3.filter = Filtrarea produselor dupa anumite criterii")
        print("4.undo = Reface ultimele operatii")
        
    
    def __ui_add_produs(self):
        '''
            Functie care apeleaza functia de adaugare a unui produs in lista
        '''
        id_produs = int(input("introduceto id produs: "))
        denumire = input("introduceti denumirea: ")
        pret = int(input("introduceti pretul: "))
        self.__service_produs.add_produs(id_produs,denumire,pret)
        print("Produs agaugat cu succes! \n")
        
        
    def __ui_delete_produse(self):
        '''
            Functie care apeleaza functia de stergere a produselor cu prop data
            key - cifra de tip string
        ''' 
        key = input("introduceti cifra: ")
        nr = self.__service_produs.delete_produs(key)
        if nr == 0:
            print("Nu a fost sters niciun produs!\n")
        else:
            print("Au fost sterse ",nr," produse!\n")
    
    
    def __ui_change_filter(self,key1,key2):
        '''
            Functie care modifca cele 2 key-uri pentru filtrare
        '''
        key1 = input("Dati textul:")
        key2 = int(input("Dati numarul:"))
        return key1,key2
    
    
    def __ui_undo(self):
        '''
            Functia care apeleaza functia de undo
        '''
        self.__service_produs.undo()
    
    
    def __ui_afisare(self, key1, key2):
        '''
            Functie de afisarea a listei si a filtrelor aplicate asupra ei
        '''
        print("\nFiltrele sunt: \nkey1: ",key1,"\nkey2: ",key2,"\nLista este: \n")
        lista = self.__service_produs.filtrare(key1,key2)
        for i in lista:
            print(i)
    
    
    def __init__(self,service_produs):
        '''
            Functie de initializare a clasei UI
            service_produs - service-ul pentru produse
        '''
        self.__service_produs = service_produs
        self.__comenzi = {
            "0":self.__ui_print_meniu,
            "1":self.__ui_add_produs,
            "2":self.__ui_delete_produse,
            "3":self.__ui_change_filter,
            "4":self.__ui_undo
            }
        
    
    
    def run(self):
        '''
            Functie de rulare a programului
        '''
        key1=""
        key2=-1
        self.__ui_print_meniu()
        while True:
            self.__ui_afisare(key1,key2)
            cmd = input("\nAlegeti comanda:\n>>>")
            if cmd == "exit":
                print("La revedere!")
                return 
            if cmd == "3":
                key1,key2 = self.__ui_change_filter(key1,key2)
            elif cmd in self.__comenzi:
                try:
                    self.__comenzi[cmd]()
                except ValueError:
                    print("Valoare numerica invalida!\n")
                except ValidationException as ve:
                    print(ve)
                except RepoException as re:
                    print(re)
            else:
                print("Comanda invalida!\n")


